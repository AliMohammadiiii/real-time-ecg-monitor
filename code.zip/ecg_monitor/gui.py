"""Live ECG GUI for the educational monitoring prototype.

The heavy PyQtGraph/PyQt import is done lazily so that importing this module (and
the rest of the package) never fails when GUI dependencies are absent. The data
source and per-window analysis are plain NumPy code and are unit-tested without
any GUI.

Safety: the GUI always shows "Educational prototype — not a medical device.",
and when the SQI is poor/unreliable it shows
"Signal unreliable; rhythm warnings suppressed." instead of a rhythm warning.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .arrhythmia import assess_rhythm
from .detection import BeatMarkers, delineate_pqrst, detect_r_peaks
from .features import extract_features
from .filters import preprocess_ecg
from .sqi import assess_signal_quality, describe_sqi_level
from .synthetic import synthetic_ecg

SAFETY_TEXT = "Educational prototype — not a medical device."
SUPPRESSED_TEXT = "Signal unreliable; rhythm warnings suppressed."


def pyqtgraph_available() -> bool:
    """Return True if PyQtGraph and a Qt binding can be imported."""
    try:
        import pyqtgraph  # noqa: F401
        from pyqtgraph.Qt import QtWidgets  # noqa: F401
        return True
    except Exception:
        return False


INSTALL_MESSAGE = (
    "PyQtGraph and a Qt binding are required for the live GUI but are not "
    "installed.\nInstall them with, for example:\n"
    "    .venv/bin/python -m pip install pyqtgraph PyQt5\n"
    "The rest of the project (evaluation scripts, tests) works without the GUI."
)


@dataclass
class ChunkResult:
    """One streamed chunk of samples plus link-quality flags."""

    samples: np.ndarray
    lead_off: bool = False
    packet_loss_rate: float = 0.0


@dataclass
class DemoSignalSource:
    """Synthetic ECG source so the GUI runs without an Arduino."""

    fs: float = 250.0
    heart_rate_bpm: float = 72.0
    chunk_seconds: float = 0.2
    noise_std: float = 0.02
    seed: int = 7
    _buffer: np.ndarray = field(default_factory=lambda: np.asarray([]), init=False)
    _pos: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        signal, _ = synthetic_ecg(
            duration_s=60.0, sampling_rate=self.fs,
            heart_rate_bpm=self.heart_rate_bpm, noise_std=self.noise_std, seed=self.seed,
        )
        # Map to a 10-bit ADC-like range so the display matches hardware units.
        self._buffer = np.clip(np.round(512 + signal * 300), 0, 1023).astype(float)

    def read_chunk(self) -> ChunkResult:
        n = max(1, int(self.chunk_seconds * self.fs))
        if self._buffer.size == 0:
            return ChunkResult(samples=np.zeros(n))
        idx = (self._pos + np.arange(n)) % self._buffer.size
        self._pos = int((self._pos + n) % self._buffer.size)
        return ChunkResult(samples=self._buffer[idx].copy(), lead_off=False, packet_loss_rate=0.0)


@dataclass
class DatasetReplaySource:
    """Replay a fixed ECG sample array as if it were a live stream."""

    samples: np.ndarray
    fs: float = 250.0
    chunk_seconds: float = 0.2
    lead_off_flags: np.ndarray | None = None
    name: str = "dataset replay"
    loop: bool = True
    _pos: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        self.samples = np.asarray(self.samples, dtype=float)
        if self.samples.size == 0:
            self.samples = np.zeros(max(1, int(self.fs)), dtype=float)
        if self.lead_off_flags is not None:
            flags = np.asarray(self.lead_off_flags, dtype=bool)
            if flags.size != self.samples.size:
                flags = np.zeros(self.samples.size, dtype=bool)
            self.lead_off_flags = flags

    def read_chunk(self) -> ChunkResult:
        n = max(1, int(self.chunk_seconds * self.fs))
        if self.loop:
            idx = (self._pos + np.arange(n)) % self.samples.size
            self._pos = int((self._pos + n) % self.samples.size)
            flags = self.lead_off_flags[idx] if self.lead_off_flags is not None else np.zeros(n, dtype=bool)
            return ChunkResult(samples=self.samples[idx].copy(), lead_off=bool(np.mean(flags) > 0.1))
        start = self._pos
        stop = min(self.samples.size, self._pos + n)
        self._pos = stop
        chunk = self.samples[start:stop]
        if chunk.size < n:
            fill = float(chunk[-1]) if chunk.size else float(self.samples[-1])
            chunk = np.pad(chunk, (0, n - chunk.size), mode="constant", constant_values=fill)
        flags = self.lead_off_flags[start:stop] if self.lead_off_flags is not None else np.zeros(stop - start, dtype=bool)
        return ChunkResult(samples=chunk.copy(), lead_off=bool(flags.size and np.mean(flags) > 0.1))

    def current_scenario_info(self) -> dict:
        return {
            "mode": "Dataset replay",
            "scenario": self.name,
            "expected": "Replay waveform; validate markers, SQI, warnings, and latency.",
        }


@dataclass
class LiveAnalysis:
    """Result of analysing the current display window."""

    r_peaks: np.ndarray
    markers: list[BeatMarkers]
    hr_bpm: float | None
    sqi_level: str
    sqi_score: float
    sqi_label: str
    sqi_description: str
    morphology_allowed: bool
    lead_off: bool
    packet_loss_rate: float
    warning_label: str
    warning_suppressed: bool
    ml_advisory: str | None = None


def analyze_window(
    buffer: np.ndarray | list[float],
    fs: float,
    lead_off: bool = False,
    packet_loss_rate: float = 0.0,
    ml_model=None,
) -> LiveAnalysis:
    """Analyse one display window: detection, SQI, warnings, optional ML advisory.

    Handles short/empty buffers and poor SQI gracefully (empty detections,
    suppressed warnings).
    """
    values = np.asarray(buffer, dtype=float)
    if values.size < int(0.8 * fs) or float(np.var(values)) < 1e-9:
        return LiveAnalysis(
            r_peaks=np.asarray([], dtype=int), markers=[], hr_bpm=None,
            sqi_level="unreliable", sqi_score=0.0,
            sqi_label=describe_sqi_level("unreliable"),
            sqi_description="Too few samples or flatline; analysis suppressed.",
            morphology_allowed=False,
            lead_off=lead_off,
            packet_loss_rate=packet_loss_rate, warning_label=SUPPRESSED_TEXT,
            warning_suppressed=True, ml_advisory=None,
        )

    r_peaks = detect_r_peaks(values, fs, analysis_allowed=not lead_off)
    sqi = assess_signal_quality(
        values, r_peaks=r_peaks, lead_off=lead_off,
        adc_min=0, adc_max=1023, packet_loss_rate=packet_loss_rate,
    )
    markers = delineate_pqrst(values, fs, r_peaks, sqi.level)
    features = extract_features(values, fs, markers)
    assessment = assess_rhythm(features)

    if not sqi.warning_allowed:
        warning_label = SUPPRESSED_TEXT
        suppressed = True
    else:
        warning_label = assessment.label
        suppressed = False

    ml_advisory = _ml_advisory(values, fs, markers, sqi, ml_model)

    return LiveAnalysis(
        r_peaks=r_peaks, markers=markers, hr_bpm=features.mean_hr_bpm,
        sqi_level=sqi.level, sqi_score=float(sqi.score),
        sqi_label=sqi.label, sqi_description=sqi.description,
        morphology_allowed=sqi.morphology_allowed, lead_off=lead_off,
        packet_loss_rate=packet_loss_rate, warning_label=warning_label,
        warning_suppressed=suppressed, ml_advisory=ml_advisory,
    )


def display_waveform(values: np.ndarray | list[float], fs: float) -> np.ndarray:
    """Return the filtered waveform used by the GUI display.

    Recording stays raw; this only improves the live view by removing slow
    baseline drift and power-line/high-frequency clutter.
    """
    samples = np.asarray(values, dtype=float)
    if samples.size < 8:
        return samples.copy()
    filtered = preprocess_ecg(samples, fs).display
    if filtered.size >= 5:
        kernel = np.ones(5, dtype=float) / 5.0
        filtered = np.convolve(filtered, kernel, mode="same")
    return filtered


def _ml_advisory(values, fs, markers, sqi, ml_model) -> str | None:
    """Optional exploratory ML advisory; suppressed when SQI is poor."""
    if ml_model is None or not markers or not sqi.warning_allowed:
        return None
    try:
        from .ml_features import feature_matrix_from_markers

        x = feature_matrix_from_markers(values, fs, markers, sqi.level)
        pred = ml_model.predict(x, sqi_level=sqi.level)
        pred = np.asarray(pred, dtype=object)
        if pred.size == 0 or np.all(pred == "suppressed_low_sqi"):
            return None
        warning_like = int(np.sum(pred == "warning_like"))
        return f"exploratory ML advisory: {warning_like}/{pred.size} beats warning-like (non-diagnostic)"
    except Exception:
        return None


def _relative_marker_indices(marker_indices_abs: np.ndarray, buffer_start_abs: int, buffer_size: int) -> np.ndarray:
    """Map absolute sample indices into the current scrolling display buffer."""
    marker_indices_abs = np.asarray(marker_indices_abs, dtype=int)
    if marker_indices_abs.size == 0 or buffer_size <= 0:
        return np.asarray([], dtype=int)
    relative = marker_indices_abs - int(buffer_start_abs)
    return relative[(0 <= relative) & (relative < buffer_size)]


def run_gui(source, fs: float, window_seconds: float = 10.0, ml_model=None, log_output=None) -> int:
    """Launch the live GUI. Returns an exit code; requires PyQtGraph.

    ``source`` must provide ``read_chunk() -> ChunkResult``.
    """
    if not pyqtgraph_available():
        print(INSTALL_MESSAGE)
        return 1

    import pyqtgraph as pg
    from pyqtgraph.Qt import QtCore, QtWidgets

    app = QtWidgets.QApplication.instance() or QtWidgets.QApplication([])
    win = QtWidgets.QWidget()
    win.setWindowTitle("Live ECG — educational prototype (not a medical device)")
    layout = QtWidgets.QVBoxLayout(win)

    safety = QtWidgets.QLabel(SAFETY_TEXT)
    safety.setStyleSheet("color: #b00; font-weight: bold;")
    layout.addWidget(safety)

    status = QtWidgets.QLabel("HR: -- | SQI: -- | lead-off: -- | loss: --")
    layout.addWidget(status)
    sqi_detail = QtWidgets.QLabel("")
    layout.addWidget(sqi_detail)
    warning = QtWidgets.QLabel("")
    warning.setStyleSheet("font-weight: bold;")
    layout.addWidget(warning)
    ml_label = QtWidgets.QLabel("")
    layout.addWidget(ml_label)
    scenario_label = QtWidgets.QLabel("")
    scenario_label.setStyleSheet("font-family: monospace;")
    layout.addWidget(scenario_label)

    plot = pg.PlotWidget()
    plot.setLabel("bottom", "time", "s")
    plot.setBackground("w")
    plot.showGrid(x=True, y=True, alpha=0.25)
    plot.setLabel("left", "filtered ECG", units="ADC deviation")
    plot.addLegend(offset=(-10, 10))
    curve = plot.plot(pen=pg.mkPen("#0072B2", width=1.6), name="filtered ECG")
    marker_items = {
        "P": plot.plot([], [], pen=None, symbol="o", symbolSize=7, symbolBrush=pg.mkBrush("#2ca02c"), name="P"),
        "Q": plot.plot([], [], pen=None, symbol="o", symbolSize=7, symbolBrush=pg.mkBrush("#ffbf00"), name="Q"),
        "R": plot.plot([], [], pen=None, symbol="o", symbolSize=10, symbolBrush=pg.mkBrush("#d62728"), name="R"),
        "S": plot.plot([], [], pen=None, symbol="o", symbolSize=7, symbolBrush=pg.mkBrush("#ff7f0e"), name="S"),
        "T": plot.plot([], [], pen=None, symbol="o", symbolSize=7, symbolBrush=pg.mkBrush("#9467bd"), name="T"),
    }
    layout.addWidget(plot)

    import time

    window_len = max(1, int(window_seconds * fs))
    buffer = np.asarray([], dtype=float)
    sample_cursor = 0
    log_file = open(log_output, "w") if log_output else None
    marker_labels = tuple(marker_items.keys())
    state = {
        "last_analysis": 0.0,
        "analysis": None,
        "marker_abs": {label: np.asarray([], dtype=int) for label in marker_labels},
    }
    # Re-run the (heavier) detection/SQI at most a few times per second; the
    # scrolling waveform itself is redrawn every tick so it stays smooth.
    analysis_period_s = 0.4

    def render_markers() -> None:
        buffer_start_abs = sample_cursor - buffer.size
        visible = display_waveform(buffer, fs)
        analysis = state.get("analysis")
        for label in marker_labels:
            if label != "R" and analysis is not None and not analysis.morphology_allowed:
                marker_items[label].setData([], [])
                continue
            idx = _relative_marker_indices(state["marker_abs"][label], buffer_start_abs, buffer.size)
            marker_items[label].setData(idx / fs if idx.size else [], visible[idx] if idx.size else [])

    def update():
        nonlocal buffer, sample_cursor
        chunk = source.read_chunk()
        samples = np.asarray(chunk.samples, dtype=float)
        if samples.size:
            buffer = np.concatenate([buffer, samples])[-window_len:]
            sample_cursor += int(samples.size)
            if log_file is not None:
                for v in samples:
                    log_file.write(f"{v}\n")
        t = np.arange(buffer.size) / fs
        visible = display_waveform(buffer, fs)
        curve.setData(t, visible)  # cheap redraw every tick -> smooth scrolling

        now = time.monotonic()
        if state["analysis"] is not None and now - state["last_analysis"] < analysis_period_s:
            render_markers()
            return  # skip the expensive analysis this tick
        state["last_analysis"] = now
        analysis = analyze_window(buffer, fs, chunk.lead_off, chunk.packet_loss_rate, ml_model)
        state["analysis"] = analysis
        buffer_start_abs = sample_cursor - buffer.size
        marker_indices = {
            "P": [m.p for m in analysis.markers if m.p is not None],
            "Q": [m.q for m in analysis.markers if m.q is not None],
            "R": [m.r for m in analysis.markers],
            "S": [m.s for m in analysis.markers if m.s is not None],
            "T": [m.t for m in analysis.markers if m.t is not None],
        }
        for label, indices in marker_indices.items():
            idx = np.asarray([i for i in indices if 0 <= i < buffer.size], dtype=int)
            state["marker_abs"][label] = buffer_start_abs + idx
        render_markers()
        hr = f"{analysis.hr_bpm:.0f}" if analysis.hr_bpm else "--"
        status.setText(
            f"HR: {hr} bpm | SQI: {analysis.sqi_label} ({analysis.sqi_score:.2f}) | "
            f"lead-off: {analysis.lead_off} | loss: {analysis.packet_loss_rate:.1%}"
        )
        sqi_detail.setText(analysis.sqi_description)
        warning.setText(analysis.warning_label)
        warning.setStyleSheet(
            "color: #b00; font-weight: bold;" if analysis.warning_suppressed else "font-weight: bold;"
        )
        ml_label.setText(analysis.ml_advisory or "")
        if hasattr(source, "current_scenario_info"):
            info = source.current_scenario_info()
            scenario_label.setText(
                f"Mode: {info.get('mode', '--')} | Scenario: {info.get('scenario', '--')} | "
                f"Expected: {info.get('expected', '--')}"
            )
        else:
            scenario_label.setText("Mode: Live Arduino | Scenario: hardware stream | Expected: stable SQI and packet flow")

    timer = QtCore.QTimer()
    timer.timeout.connect(update)
    timer.start(int(getattr(source, "chunk_seconds", 0.2) * 1000))

    win.resize(900, 500)
    win.show()
    try:
        return int(app.exec() if hasattr(app, "exec") else app.exec_())
    finally:
        if log_file is not None:
            log_file.close()
        close_source = getattr(source, "close", None)
        if callable(close_source):
            close_source()
