from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from .features import ECGFeatures


@dataclass(frozen=True)
class RhythmAssessment:
    label: str
    risk_score: float
    reasons: tuple[str, ...]


def assess_rhythm(features: ECGFeatures) -> RhythmAssessment:
    reasons: list[str] = []
    risk = 0.0

    if features.signal_quality < 0.25:
        return RhythmAssessment(
            label="Poor signal / unreliable analysis",
            risk_score=1.0,
            reasons=("Suppressing rhythm warnings because signal quality is too low",),
        )

    if features.mean_hr_bpm is not None:
        if features.mean_hr_bpm < 50.0:
            reasons.append("Possible bradycardia")
            risk += min(0.35, (50.0 - features.mean_hr_bpm) / 80.0 + 0.10)
        elif features.mean_hr_bpm < 60.0:
            reasons.append("Low heart-rate status")
            risk += min(0.15, (60.0 - features.mean_hr_bpm) / 100.0)
        elif features.mean_hr_bpm > 100.0:
            reasons.append("Possible tachycardia")
            risk += min(0.30, (features.mean_hr_bpm - 100.0) / 120.0)

    if features.rr_cv is not None and features.rr_cv > 0.15:
        reasons.append("Irregular RR intervals")
        risk += min(0.30, features.rr_cv)

    if features.rr_intervals_s.size >= 3:
        median_rr = float(np.median(features.rr_intervals_s))
        short_then_pause = False
        for i in range(features.rr_intervals_s.size - 1):
            if features.rr_intervals_s[i] < 0.75 * median_rr and features.rr_intervals_s[i + 1] > 1.20 * median_rr:
                short_then_pause = True
                break
        if short_then_pause:
            reasons.append("Premature-beat suspicion")
            risk += 0.20

    if features.signal_quality >= 0.70 and features.qrs_durations_s.size:
        wide_ratio = float((features.qrs_durations_s > 0.120).mean())
        if wide_ratio > 0.25:
            reasons.append("Wide QRS warning")
            risk += min(0.25, wide_ratio * 0.25)

    risk = max(0.0, min(1.0, risk))
    if not reasons:
        return RhythmAssessment(label="Normal rhythm candidate", risk_score=risk, reasons=("No rule-based warning",))
    if risk >= 0.60:
        label = "High preliminary rhythm warning"
    elif risk >= 0.30:
        label = "Moderate preliminary rhythm warning"
    else:
        label = "Low preliminary rhythm warning"
    return RhythmAssessment(label=label, risk_score=risk, reasons=tuple(reasons))
